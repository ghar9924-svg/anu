import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../core/theme/theme.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('About')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: AppTheme.premiumGradient,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: const Icon(CupertinoIcons.building_2_fill, size: 64, color: Colors.white),
              ),
              const SizedBox(height: 24),
              const Text(
                'Smart Finance',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppTheme.textDark),
              ),
              const SizedBox(height: 8),
              const Text(
                'Version 1.0.0',
                style: TextStyle(color: AppTheme.textLight),
              ),
              const SizedBox(height: 32),
              const Text(
                'Designed specifically for iOS devices. We aim to provide the most clean, premium, and easy-to-use financial utility tools available on the App Store.',
                textAlign: TextAlign.center,
                style: TextStyle(height: 1.5, color: AppTheme.textDark),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
