import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../utils/theme.dart';
import '../widgets/custom_widgets.dart';
import '../services/ad_service.dart';

class SipCalculatorScreen extends ConsumerStatefulWidget {
  const SipCalculatorScreen({super.key});

  @override
  ConsumerState<SipCalculatorScreen> createState() => _SipCalculatorScreenState();
}

class _SipCalculatorScreenState extends ConsumerState<SipCalculatorScreen> {
  final TextEditingController _investmentController = TextEditingController();
  final TextEditingController _rateController = TextEditingController();
  final TextEditingController _periodController = TextEditingController();
  
  double? _totalValue;
  double? _invested;
  double? _returns;

  void _calculate() {
    FocusScope.of(context).unfocus();
    ref.read(adServiceProvider).showRewardedAd(onReward: () {
      final p = double.tryParse(_investmentController.text) ?? 0;
      final i = (double.tryParse(_rateController.text) ?? 0) / 12 / 100;
      final n = (double.tryParse(_periodController.text) ?? 0) * 12;

      if (p > 0 && i > 0 && n > 0) {
        // M = P × ({[1 + i]^n – 1} / i) × (1 + i)
        final m = p * ((pow(1 + i, n) - 1) / i) * (1 + i);
        final invested = p * n;
        setState(() {
          _totalValue = m;
          _invested = invested;
          _returns = m - invested;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SIP Calculator')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomCard(
                child: Column(
                  children: [
                    CalculatorInputField(label: 'Monthly Investment', suffix: '\$', controller: _investmentController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Expected Return Rate', suffix: '%', controller: _rateController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Time Period', suffix: 'Yrs', controller: _periodController),
                    const SizedBox(height: 24),
                    CalculateButton(onPressed: _calculate),
                  ],
                ),
              ),
              if (_totalValue != null) ...[
                const SizedBox(height: 24),
                CustomCard(
                  child: Column(
                    children: [
                      const Text('Total Value', style: TextStyle(color: AppTheme.textLight)),
                      const SizedBox(height: 8),
                      Text(
                        '\$${_totalValue!.toStringAsFixed(2)}',
                        style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.green),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _buildBox('Invested', _invested!),
                          _buildBox('Returns', _returns!),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
      bottomNavigationBar: const BannerAdWidget(),
    );
  }
  
  Widget _buildBox(String title, double value) {
    return Column(
      children: [
        Text(title, style: const TextStyle(color: AppTheme.textLight, fontSize: 13)),
        const SizedBox(height: 4),
        Text('\$${value.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
      ],
    );
  }
}
