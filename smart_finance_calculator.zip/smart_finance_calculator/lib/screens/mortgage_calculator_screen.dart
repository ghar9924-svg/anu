import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../utils/theme.dart';
import '../widgets/custom_widgets.dart';
import '../services/ad_service.dart';

class MortgageCalculatorScreen extends ConsumerStatefulWidget {
  const MortgageCalculatorScreen({super.key});

  @override
  ConsumerState<MortgageCalculatorScreen> createState() => _MortgageCalculatorScreenState();
}

class _MortgageCalculatorScreenState extends ConsumerState<MortgageCalculatorScreen> {
  final TextEditingController _homeValueController = TextEditingController();
  final TextEditingController _downPaymentController = TextEditingController();
  final TextEditingController _rateController = TextEditingController();
  final TextEditingController _yearsController = TextEditingController();
  
  double? _monthlyPayment;
  double? _loanAmount;

  void _calculate() {
    FocusScope.of(context).unfocus();
    ref.read(adServiceProvider).showRewardedAd(onReward: () {
      final homeValue = double.tryParse(_homeValueController.text) ?? 0;
      final downPayment = double.tryParse(_downPaymentController.text) ?? 0;
      final r = (double.tryParse(_rateController.text) ?? 0) / 12 / 100;
      final n = (double.tryParse(_yearsController.text) ?? 0) * 12;

      final p = homeValue - downPayment;

      if (p > 0 && r > 0 && n > 0) {
        final m = (p * r * pow(1 + r, n)) / (pow(1 + r, n) - 1);
        setState(() {
          _loanAmount = p;
          _monthlyPayment = m;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mortgage Calculator')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomCard(
                child: Column(
                  children: [
                    CalculatorInputField(label: 'Home Value', suffix: '\$', controller: _homeValueController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Down Payment', suffix: '\$', controller: _downPaymentController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Interest Rate', suffix: '%', controller: _rateController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Loan Term', suffix: 'Yrs', controller: _yearsController),
                    const SizedBox(height: 24),
                    CalculateButton(onPressed: _calculate),
                  ],
                ),
              ),
              if (_monthlyPayment != null) ...[
                const SizedBox(height: 24),
                CustomCard(
                  child: Column(
                    children: [
                      const Text('Monthly Mortgage Payment', style: TextStyle(color: AppTheme.textLight)),
                      const SizedBox(height: 8),
                      Text(
                        '\$${_monthlyPayment!.toStringAsFixed(2)}',
                        style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: AppTheme.primaryBlue),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Loan Amount: \$${_loanAmount!.toStringAsFixed(2)}',
                        style: const TextStyle(fontWeight: FontWeight.w600, color: AppTheme.textLight),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
      bottomNavigationBar: const BannerAdWidget(),
    );
  }
}
