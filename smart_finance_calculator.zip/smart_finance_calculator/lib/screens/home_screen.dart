import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../utils/theme.dart';
import '../widgets/custom_widgets.dart';

// Import all calculators (placeholders for now)
import 'emi_calculator_screen.dart';
import 'loan_eligibility_screen.dart';
import 'interest_rate_screen.dart';
import 'sip_calculator_screen.dart';
import 'compound_interest_screen.dart';
import 'simple_interest_screen.dart';
import 'mortgage_calculator_screen.dart';
import 'credit_card_screen.dart';
import 'loan_comparison_screen.dart';
import 'savings_goal_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> calculators = [
      {'title': 'EMI', 'icon': CupertinoIcons.money_dollar_circle, 'page': const EmiCalculatorScreen()},
      {'title': 'Eligibility', 'icon': CupertinoIcons.checkmark_shield, 'page': const LoanEligibilityScreen()},
      {'title': 'Interest Rate', 'icon': CupertinoIcons.percent, 'page': const InterestRateScreen()},
      {'title': 'SIP', 'icon': CupertinoIcons.chart_pie, 'page': const SipCalculatorScreen()},
      {'title': 'Compound', 'icon': CupertinoIcons.chart_bar_alt_fill, 'page': const CompoundInterestScreen()},
      {'title': 'Simple Int.', 'icon': CupertinoIcons.money_dollar, 'page': const SimpleInterestScreen()},
      {'title': 'Mortgage', 'icon': CupertinoIcons.house, 'page': const MortgageCalculatorScreen()},
      {'title': 'Credit Card', 'icon': CupertinoIcons.creditcard, 'page': const CreditCardScreen()},
      {'title': 'Compare Loan', 'icon': CupertinoIcons.arrow_right_arrow_left, 'page': const LoanComparisonScreen()},
      {'title': 'Savings Goal', 'icon': CupertinoIcons.flag, 'page': const SavingsGoalScreen()},
    ];

    return Scaffold(
      body: Stack(
        children: [
          // Background Gradient Header
          Container(
            height: 280,
            decoration: const BoxDecoration(
              gradient: AppTheme.premiumGradient,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(40),
                bottomRight: Radius.circular(40),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Smart Finance',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.2,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Select a calculator to start',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: GridView.builder(
                      physics: const BouncingScrollPhysics(),
                      itemCount: calculators.length,
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 16,
                        mainAxisSpacing: 16,
                        childAspectRatio: 1.1,
                      ),
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              CupertinoPageRoute(
                                builder: (context) => calculators[index]['page'],
                              ),
                            );
                          },
                          child: CustomCard(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: AppTheme.backgroundLight,
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    calculators[index]['icon'],
                                    size: 32,
                                    color: AppTheme.primaryBlue,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  calculators[index]['title'],
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                    color: AppTheme.textDark,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: const BannerAdWidget(),
    );
  }
}
