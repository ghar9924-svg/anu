import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../core/theme/theme.dart';
import '../../widgets/custom_widgets.dart';

import '../settings/settings_screen.dart';
import '../about/about_screen.dart';

import '../calculators/emi_calculator_screen.dart';
import '../calculators/loan_eligibility_screen.dart';
import '../calculators/interest_rate_screen.dart';
import '../calculators/sip_calculator_screen.dart';
import '../calculators/compound_interest_screen.dart';
import '../calculators/simple_interest_screen.dart';
import '../calculators/mortgage_calculator_screen.dart';
import '../calculators/credit_card_screen.dart';
import '../calculators/loan_comparison_screen.dart';
import '../calculators/savings_goal_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  
  final List<Widget> _tabs = [
    const _CalculatorsGridTab(),
    const SettingsScreen(),
    const AboutScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _tabs,
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const BannerAdWidget(),
          BottomNavigationBar(
            currentIndex: _currentIndex,
            onTap: (index) => setState(() => _currentIndex = index),
            selectedItemColor: AppTheme.primaryPurple,
            unselectedItemColor: AppTheme.textLight,
            backgroundColor: AppTheme.cardColorLight,
            elevation: 16,
            items: const [
              BottomNavigationBarItem(
                icon: Icon(CupertinoIcons.square_grid_2x2_fill),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                icon: Icon(CupertinoIcons.settings),
                label: 'Settings',
              ),
              BottomNavigationBarItem(
                icon: Icon(CupertinoIcons.info_circle_fill),
                label: 'About',
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _CalculatorsGridTab extends StatelessWidget {
  const _CalculatorsGridTab();

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> calculators = [
      {'title': 'EMI', 'icon': CupertinoIcons.money_dollar_circle, 'page': const EmiCalculatorScreen()},
      {'title': 'Eligibility', 'icon': CupertinoIcons.checkmark_shield, 'page': const LoanEligibilityScreen()},
      {'title': 'Interest Rate', 'icon': CupertinoIcons.percent, 'page': const InterestRateScreen()},
      {'title': 'SIP', 'icon': CupertinoIcons.chart_pie, 'page': const SipCalculatorScreen()},
      {'title': 'Compound', 'icon': CupertinoIcons.chart_bar_alt_fill, 'page': const CompoundInterestScreen()},
      {'title': 'Simple Int.', 'icon': CupertinoIcons.money_dollar, 'page': const SimpleInterestScreen()},
      {'title': 'Mortgage', 'icon': CupertinoIcons.house, 'page': const MortgageCalculatorScreen()},
      {'title': 'Credit Card', 'icon': CupertinoIcons.creditcard, 'page': const CreditCardScreen()},
      {'title': 'Compare', 'icon': CupertinoIcons.arrow_right_arrow_left, 'page': const LoanComparisonScreen()},
      {'title': 'Savings Goal', 'icon': CupertinoIcons.flag, 'page': const SavingsGoalScreen()},
    ];

    return Stack(
      children: [
        Container(
          height: 300,
          decoration: const BoxDecoration(
            gradient: AppTheme.premiumGradient,
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(40),
              bottomRight: Radius.circular(40),
            ),
          ),
        ),
        SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 24.0, vertical: 32.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Dashboard',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.2,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'What would you like to calculate?',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: GridView.builder(
                    physics: const BouncingScrollPhysics(),
                    itemCount: calculators.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      childAspectRatio: 1.05,
                    ),
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            CupertinoPageRoute(
                              builder: (context) => calculators[index]['page'],
                            ),
                          );
                        },
                        child: CustomCard(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(14),
                                decoration: BoxDecoration(
                                  color: AppTheme.backgroundLight,
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  calculators[index]['icon'],
                                  size: 32,
                                  color: AppTheme.primaryPurple,
                                ),
                              ),
                              const SizedBox(height: 16),
                              Text(
                                calculators[index]['title'],
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                  color: AppTheme.textDark,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
