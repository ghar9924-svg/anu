import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/theme.dart';
import '../../widgets/custom_widgets.dart';
import '../../services/ad_service.dart';

class InterestRateScreen extends ConsumerStatefulWidget {
  const InterestRateScreen({super.key});

  @override
  ConsumerState<InterestRateScreen> createState() => _InterestRateScreenState();
}

class _InterestRateScreenState extends ConsumerState<InterestRateScreen> {
  final TextEditingController _principalController = TextEditingController();
  final TextEditingController _emiController = TextEditingController();
  final TextEditingController _tenureController = TextEditingController();
  
  double? _estimatedRate;

  void _calculate() {
    FocusScope.of(context).unfocus();
    ref.read(adServiceProvider).showRewardedAd(onReward: () {
      final p = double.tryParse(_principalController.text) ?? 0;
      final emi = double.tryParse(_emiController.text) ?? 0;
      final n = (double.tryParse(_tenureController.text) ?? 0) * 12;

      if (p > 0 && emi > 0 && n > 0 && emi * n > p) {
        double minRate = 0.0;
        double maxRate = 100.0;
        double r = 0;
        for (int i = 0; i < 50; i++) {
          double mid = (minRate + maxRate) / 2;
          double rMonthly = mid / 12 / 100;
          double calcEmi = (p * rMonthly * pow(1 + rMonthly, n)) / (pow(1 + rMonthly, n) - 1);
          if (calcEmi > emi) maxRate = mid;
          else minRate = mid;
          r = mid;
        }
        setState(() => _estimatedRate = r);
      }
    });
  }

  void _reset() {
    _principalController.clear();
    _emiController.clear();
    _tenureController.clear();
    setState(() => _estimatedRate = null);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Interest Rate'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _reset)],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomCard(
                child: Column(
                  children: [
                    CalculatorInputField(label: 'Loan Amount', suffix: '\$', controller: _principalController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Monthly EMI', suffix: '\$', controller: _emiController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Tenure', suffix: 'Yrs', controller: _tenureController),
                    const SizedBox(height: 24),
                    CalculateButton(onPressed: _calculate),
                  ],
                ),
              ),
              if (_estimatedRate != null) ...[
                const SizedBox(height: 24),
                CustomCard(
                  child: Column(
                    children: [
                      const Text('Estimated Interest Rate', style: TextStyle(color: AppTheme.textLight, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text(
                        '${_estimatedRate!.toStringAsFixed(2)}%',
                        style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: AppTheme.primaryPurple),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
