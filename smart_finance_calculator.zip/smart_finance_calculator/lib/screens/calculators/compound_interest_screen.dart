import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/theme.dart';
import '../../widgets/custom_widgets.dart';
import '../../services/ad_service.dart';

class CompoundInterestScreen extends ConsumerStatefulWidget {
  const CompoundInterestScreen({super.key});

  @override
  ConsumerState<CompoundInterestScreen> createState() => _CompoundInterestScreenState();
}

class _CompoundInterestScreenState extends ConsumerState<CompoundInterestScreen> {
  final TextEditingController _principalController = TextEditingController();
  final TextEditingController _rateController = TextEditingController();
  final TextEditingController _yearsController = TextEditingController();
  
  double? _totalAmount;
  double? _interestEarned;

  void _calculate() {
    FocusScope.of(context).unfocus();
    ref.read(adServiceProvider).showRewardedAd(onReward: () {
      final p = double.tryParse(_principalController.text) ?? 0;
      final r = (double.tryParse(_rateController.text) ?? 0) / 100;
      final t = double.tryParse(_yearsController.text) ?? 0;

      if (p > 0 && r > 0 && t > 0) {
        final a = p * pow(1 + r, t);
        setState(() {
          _totalAmount = a;
          _interestEarned = a - p;
        });
      }
    });
  }

  void _reset() {
    _principalController.clear();
    _rateController.clear();
    _yearsController.clear();
    setState(() { _totalAmount = null; _interestEarned = null; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Compound Interest'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _reset)],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomCard(
                child: Column(
                  children: [
                    CalculatorInputField(label: 'Principal Amount', suffix: '\$', controller: _principalController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Interest Rate (Annual)', suffix: '%', controller: _rateController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Time Period', suffix: 'Yrs', controller: _yearsController),
                    const SizedBox(height: 24),
                    CalculateButton(onPressed: _calculate),
                  ],
                ),
              ),
              if (_totalAmount != null) ...[
                const SizedBox(height: 24),
                CustomCard(
                  child: Column(
                    children: [
                      const Text('Maturity Value', style: TextStyle(color: AppTheme.textLight, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text(
                        '\$${_totalAmount!.toStringAsFixed(2)}',
                        style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: AppTheme.primaryPurple),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Total Interest: \$${_interestEarned!.toStringAsFixed(2)}',
                        style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.green),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
