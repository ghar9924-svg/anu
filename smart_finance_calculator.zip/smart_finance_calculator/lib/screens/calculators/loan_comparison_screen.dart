import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/theme.dart';
import '../../widgets/custom_widgets.dart';
import '../../services/ad_service.dart';

class LoanComparisonScreen extends ConsumerStatefulWidget {
  const LoanComparisonScreen({super.key});

  @override
  ConsumerState<LoanComparisonScreen> createState() => _LoanComparisonScreenState();
}

class _LoanComparisonScreenState extends ConsumerState<LoanComparisonScreen> {
  final TextEditingController _amount1 = TextEditingController();
  final TextEditingController _rate1 = TextEditingController();
  final TextEditingController _years1 = TextEditingController();
  
  final TextEditingController _amount2 = TextEditingController();
  final TextEditingController _rate2 = TextEditingController();
  final TextEditingController _years2 = TextEditingController();
  
  Map<String, double>? _result1;
  Map<String, double>? _result2;

  void _calculate() {
    FocusScope.of(context).unfocus();
    ref.read(adServiceProvider).showRewardedAd(onReward: () {
      _result1 = _computeLoan(_amount1.text, _rate1.text, _years1.text);
      _result2 = _computeLoan(_amount2.text, _rate2.text, _years2.text);
      setState(() {});
    });
  }

  Map<String, double>? _computeLoan(String ast, String rst, String yst) {
    final p = double.tryParse(ast) ?? 0;
    final r = (double.tryParse(rst) ?? 0) / 12 / 100;
    final n = (double.tryParse(yst) ?? 0) * 12;

    if (p > 0 && r > 0 && n > 0) {
      final emi = (p * r * pow(1 + r, n)) / (pow(1 + r, n) - 1);
      final totalPmt = emi * n;
      return {
        'emi': emi,
        'interest': totalPmt - p,
      };
    }
    return null;
  }

  void _reset() {
    _amount1.clear(); _rate1.clear(); _years1.clear();
    _amount2.clear(); _rate2.clear(); _years2.clear();
    setState(() { _result1 = null; _result2 = null; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Compare Loans'),
         actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _reset)],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: CustomCard(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        children: [
                          const Text('Loan 1', style: TextStyle(fontWeight: FontWeight.bold, color: AppTheme.primaryPurple)),
                          const SizedBox(height: 12),
                          CalculatorInputField(label: 'Amount', suffix: '\$', controller: _amount1),
                          const SizedBox(height: 12),
                          CalculatorInputField(label: 'Rate', suffix: '%', controller: _rate1),
                          const SizedBox(height: 12),
                          CalculatorInputField(label: 'Years', suffix: 'Y', controller: _years1),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: CustomCard(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        children: [
                          const Text('Loan 2', style: TextStyle(fontWeight: FontWeight.bold, color: AppTheme.primaryBlue)),
                          const SizedBox(height: 12),
                          CalculatorInputField(label: 'Amount', suffix: '\$', controller: _amount2),
                          const SizedBox(height: 12),
                          CalculatorInputField(label: 'Rate', suffix: '%', controller: _rate2),
                          const SizedBox(height: 12),
                          CalculatorInputField(label: 'Years', suffix: 'Y', controller: _years2),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              CalculateButton(onPressed: _calculate),
              
              if (_result1 != null || _result2 != null) ...[
                const SizedBox(height: 24),
                CustomCard(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      if (_result1 != null)
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Text('Loan 1', style: TextStyle(fontWeight: FontWeight.bold, color: AppTheme.primaryPurple)),
                            const SizedBox(height: 8),
                            Text('EMI: \$${_result1!['emi']!.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w600)),
                            const SizedBox(height: 4),
                            Text('Int: \$${_result1!['interest']!.toStringAsFixed(0)}', style: const TextStyle(color: AppTheme.textLight)),
                          ],
                        ),
                      if (_result2 != null)
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Text('Loan 2', style: TextStyle(fontWeight: FontWeight.bold, color: AppTheme.primaryBlue)),
                            const SizedBox(height: 8),
                            Text('EMI: \$${_result2!['emi']!.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w600)),
                            const SizedBox(height: 4),
                            Text('Int: \$${_result2!['interest']!.toStringAsFixed(0)}', style: const TextStyle(color: AppTheme.textLight)),
                          ],
                        ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
