import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/theme.dart';
import '../../widgets/custom_widgets.dart';
import '../../services/ad_service.dart';

class LoanEligibilityScreen extends ConsumerStatefulWidget {
  const LoanEligibilityScreen({super.key});

  @override
  ConsumerState<LoanEligibilityScreen> createState() => _LoanEligibilityScreenState();
}

class _LoanEligibilityScreenState extends ConsumerState<LoanEligibilityScreen> {
  final TextEditingController _incomeController = TextEditingController();
  final TextEditingController _emiController = TextEditingController();
  final TextEditingController _rateController = TextEditingController();
  final TextEditingController _tenureController = TextEditingController();
  
  double? _eligibleAmount;

  void _calculate() {
    FocusScope.of(context).unfocus();
    ref.read(adServiceProvider).showRewardedAd(onReward: () {
      final income = double.tryParse(_incomeController.text) ?? 0;
      final existingEmi = double.tryParse(_emiController.text) ?? 0;
      final r = (double.tryParse(_rateController.text) ?? 0) / 12 / 100;
      final n = (double.tryParse(_tenureController.text) ?? 0) * 12;

      if (income > 0 && r > 0 && n > 0) {
        final disposableIncome = (income * 0.5) - existingEmi;
        if (disposableIncome > 0) {
          double powVal = 1.0;
          for (int i = 0; i < n; i++) powVal *= (1 + r);
          final eligible = disposableIncome * (powVal - 1) / (r * powVal);
          setState(() {
            _eligibleAmount = eligible;
          });
        } else {
          setState(() {
            _eligibleAmount = 0;
          });
        }
      }
    });
  }

  void _reset() {
    _incomeController.clear();
    _emiController.clear();
    _rateController.clear();
    _tenureController.clear();
    setState(() { _eligibleAmount = null; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Loan Eligibility'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _reset)],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomCard(
                child: Column(
                  children: [
                    CalculatorInputField(label: 'Monthly Income', suffix: '\$', controller: _incomeController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Existing EMIs', suffix: '\$', controller: _emiController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Interest Rate', suffix: '%', controller: _rateController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Tenure', suffix: 'Yrs', controller: _tenureController),
                    const SizedBox(height: 24),
                    CalculateButton(onPressed: _calculate),
                  ],
                ),
              ),
              if (_eligibleAmount != null) ...[
                const SizedBox(height: 24),
                CustomCard(
                  child: Column(
                    children: [
                      const Text('Eligible Loan Amount', style: TextStyle(color: AppTheme.textLight, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text(
                        '\$${_eligibleAmount!.toStringAsFixed(2)}',
                        style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: AppTheme.primaryPurple),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
