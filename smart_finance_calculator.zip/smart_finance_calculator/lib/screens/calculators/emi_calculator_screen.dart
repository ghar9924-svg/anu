import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/theme.dart';
import '../../widgets/custom_widgets.dart';
import '../../services/ad_service.dart';

class EmiCalculatorScreen extends ConsumerStatefulWidget {
  const EmiCalculatorScreen({super.key});

  @override
  ConsumerState<EmiCalculatorScreen> createState() => _EmiCalculatorScreenState();
}

class _EmiCalculatorScreenState extends ConsumerState<EmiCalculatorScreen> {
  final TextEditingController _principalController = TextEditingController();
  final TextEditingController _rateController = TextEditingController();
  final TextEditingController _tenureController = TextEditingController();
  
  double? _emi;
  double? _totalInterest;
  double? _totalPayment;

  void _calculate() {
    FocusScope.of(context).unfocus();
    ref.read(adServiceProvider).showRewardedAd(onReward: () {
      final p = double.tryParse(_principalController.text) ?? 0;
      final r = (double.tryParse(_rateController.text) ?? 0) / 12 / 100;
      final n = (double.tryParse(_tenureController.text) ?? 0) * 12;

      if (p > 0 && r > 0 && n > 0) {
        final emi = (p * r * pow(1 + r, n)) / (pow(1 + r, n) - 1);
        final totalPayment = emi * n;
        setState(() {
          _emi = emi;
          _totalPayment = totalPayment;
          _totalInterest = totalPayment - p;
        });
      }
    });
  }

  void _reset() {
    _principalController.clear();
    _rateController.clear();
    _tenureController.clear();
    setState(() {
      _emi = null;
      _totalInterest = null;
      _totalPayment = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('EMI Calculator'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _reset),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomCard(
                child: Column(
                  children: [
                    CalculatorInputField(label: 'Loan Amount', suffix: '\$', controller: _principalController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Interest Rate', suffix: '%', controller: _rateController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Tenure', suffix: 'Yrs', controller: _tenureController),
                    const SizedBox(height: 24),
                    CalculateButton(onPressed: _calculate),
                  ],
                ),
              ),
              if (_emi != null) ...[
                const SizedBox(height: 24),
                CustomCard(
                  child: Column(
                    children: [
                      const Text('Monthly EMI', style: TextStyle(color: AppTheme.textLight, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text(
                        '\$${_emi!.toStringAsFixed(2)}',
                        style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: AppTheme.primaryPurple),
                      ),
                      const SizedBox(height: 24),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _buildResultBox('Total Interest', _totalInterest!),
                          _buildResultBox('Total Payment', _totalPayment!),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultBox(String title, double value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(color: AppTheme.textLight, fontSize: 13, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        Text('\$${value.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppTheme.textDark)),
      ],
    );
  }
}
