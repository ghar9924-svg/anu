import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/theme.dart';
import '../../widgets/custom_widgets.dart';
import '../../services/ad_service.dart';

class SavingsGoalScreen extends ConsumerStatefulWidget {
  const SavingsGoalScreen({super.key});

  @override
  ConsumerState<SavingsGoalScreen> createState() => _SavingsGoalScreenState();
}

class _SavingsGoalScreenState extends ConsumerState<SavingsGoalScreen> {
  final TextEditingController _goalAmtController = TextEditingController();
  final TextEditingController _initialSavedController = TextEditingController();
  final TextEditingController _yearsController = TextEditingController();
  final TextEditingController _rateController = TextEditingController();
  
  double? _monthlyDeposit;

  void _calculate() {
    FocusScope.of(context).unfocus();
    ref.read(adServiceProvider).showRewardedAd(onReward: () {
      final goal = double.tryParse(_goalAmtController.text) ?? 0;
      final saved = double.tryParse(_initialSavedController.text) ?? 0;
      final years = double.tryParse(_yearsController.text) ?? 0;
      final rate = double.tryParse(_rateController.text) ?? 0;

      if (goal > 0 && years > 0 && rate > 0) {
        final r = rate / 100 / 12;
        final n = years * 12;
        
        final fvInitial = saved * pow(1 + r, n);
        final amountNeeded = goal - fvInitial;

        if (amountNeeded <= 0) {
          setState(() => _monthlyDeposit = 0);
          return;
        }

        final pmt = amountNeeded * (r / (pow(1 + r, n) - 1));
        setState(() => _monthlyDeposit = pmt);
      }
    });
  }

  void _reset() {
    _goalAmtController.clear();
    _initialSavedController.clear();
    _yearsController.clear();
    _rateController.clear();
    setState(() => _monthlyDeposit = null);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Savings Goal'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _reset)],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomCard(
                child: Column(
                  children: [
                    CalculatorInputField(label: 'Goal Amount', suffix: '\$', controller: _goalAmtController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Initial Amount Saved', suffix: '\$', controller: _initialSavedController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Time to Reach Goal', suffix: 'Yrs', controller: _yearsController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Expected Return Rate', suffix: '%', controller: _rateController),
                    const SizedBox(height: 24),
                    CalculateButton(onPressed: _calculate),
                  ],
                ),
              ),
              if (_monthlyDeposit != null) ...[
                const SizedBox(height: 24),
                CustomCard(
                  child: Column(
                    children: [
                      const Text('Required Monthly Deposit', style: TextStyle(color: AppTheme.textLight, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text(
                        '\$${_monthlyDeposit!.toStringAsFixed(2)}',
                        style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.green),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
