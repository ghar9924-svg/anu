import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/theme.dart';
import '../../widgets/custom_widgets.dart';
import '../../services/ad_service.dart';

class CreditCardScreen extends ConsumerStatefulWidget {
  const CreditCardScreen({super.key});

  @override
  ConsumerState<CreditCardScreen> createState() => _CreditCardScreenState();
}

class _CreditCardScreenState extends ConsumerState<CreditCardScreen> {
  final TextEditingController _balanceController = TextEditingController();
  final TextEditingController _aprController = TextEditingController();
  final TextEditingController _monthsController = TextEditingController();
  
  double? _totalInterest;
  double? _payoffAmount;

  void _calculate() {
    FocusScope.of(context).unfocus();
    ref.read(adServiceProvider).showRewardedAd(onReward: () {
      final balance = double.tryParse(_balanceController.text) ?? 0;
      final apr = double.tryParse(_aprController.text) ?? 0;
      final months = double.tryParse(_monthsController.text) ?? 0;

      if (balance > 0 && apr > 0 && months > 0) {
        final monthlyRate = apr / 100 / 12;
        final p = balance;
        final r = monthlyRate;
        final n = months;
        
        final m = (p * r * (1 + r).pow(n)) / ((1 + r).pow(n) - 1);
        final totalPaid = m * n;
        
        setState(() {
          _totalInterest = totalPaid - p;
          _payoffAmount = totalPaid;
        });
      }
    });
  }

  void _reset() {
    _balanceController.clear();
    _aprController.clear();
    _monthsController.clear();
    setState(() { _totalInterest = null; _payoffAmount = null; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Credit Card Interest'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _reset)],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomCard(
                child: Column(
                  children: [
                    CalculatorInputField(label: 'Outstanding Balance', suffix: '\$', controller: _balanceController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'APR (Annual % Rate)', suffix: '%', controller: _aprController),
                    const SizedBox(height: 16),
                    CalculatorInputField(label: 'Months to Payoff', suffix: 'Mos', controller: _monthsController),
                    const SizedBox(height: 24),
                    CalculateButton(onPressed: _calculate),
                  ],
                ),
              ),
              if (_totalInterest != null) ...[
                const SizedBox(height: 24),
                CustomCard(
                  child: Column(
                    children: [
                      const Text('Total Interest Paid', style: TextStyle(color: AppTheme.textLight, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text(
                        '\$${_totalInterest!.toStringAsFixed(2)}',
                        style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.redAccent),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Total Payoff Amount: \$${_payoffAmount!.toStringAsFixed(2)}',
                        style: const TextStyle(fontWeight: FontWeight.w600, color: AppTheme.textDark),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

extension on double {
  double pow(num exponent) {
    num result = 1.0;
    for (int i = 0; i < exponent; i++) {
        result *= this;
    }
    return result.toDouble();
  }
}
