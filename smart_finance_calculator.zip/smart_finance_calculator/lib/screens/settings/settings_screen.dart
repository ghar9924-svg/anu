import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../core/theme/theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _buildSectionHeader('Preferences'),
          _buildListTile(CupertinoIcons.money_dollar_circle, 'Default Currency', 'USD (\$)'),
          _buildListTile(CupertinoIcons.chart_bar_alt_fill, 'Number Format', '1,000,000.00'),
          const SizedBox(height: 24),
          _buildSectionHeader('Support'),
          _buildListTile(CupertinoIcons.question_circle, 'Help Center', null),
          _buildListTile(CupertinoIcons.star, 'Rate Us', null),
          _buildListTile(CupertinoIcons.lock_shield, 'Privacy Policy', null),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, top: 8),
      child: Text(
        title.toUpperCase(),
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: AppTheme.textLight,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  Widget _buildListTile(IconData icon, String title, String? trailing) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppTheme.cardColorLight,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 8,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: ListTile(
        leading: Icon(icon, color: AppTheme.primaryPurple),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        trailing: trailing != null 
            ? Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(trailing, style: const TextStyle(color: AppTheme.textLight)),
                  const SizedBox(width: 8),
                  const Icon(CupertinoIcons.chevron_forward, size: 16, color: AppTheme.textLight),
                ],
              )
            : const Icon(CupertinoIcons.chevron_forward, size: 16, color: AppTheme.textLight),
        onTap: () {},
      ),
    );
  }
}
