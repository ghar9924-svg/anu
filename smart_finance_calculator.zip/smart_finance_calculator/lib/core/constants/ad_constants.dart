import 'dart:io';
import 'package:flutter/foundation.dart';

class AdConstants {
  // Provided AdMob App ID
  static const String appId = 'ca-app-pub-5811394935866235~6779391996';
  
  // Provided Production IDs
  static const String _prodBanner = 'ca-app-pub-5811394935866235/7150980983';
  static const String _prodInterstitial = 'ca-app-pub-5811394935866235/3211735974';
  static const String _prodRewarded = 'ca-app-pub-5811394935866235/2565160253';

  // Google Test IDs for Development (to prevent invalid traffic policy violations)
  static const String _testBannerId = 'ca-app-pub-3940256099942544/2934735716';
  static const String _testInterstitialId = 'ca-app-pub-3940256099942544/4411468910';
  static const String _testRewardedId = 'ca-app-pub-3940256099942544/1712485313';

  static String get bannerAdUnitId {
    if (!Platform.isIOS) return '';
    return kReleaseMode ? _prodBanner : _testBannerId;
  }

  static String get interstitialAdUnitId {
    if (!Platform.isIOS) return '';
    return kReleaseMode ? _prodInterstitial : _testInterstitialId;
  }

  static String get rewardedAdUnitId {
    if (!Platform.isIOS) return '';
    return kReleaseMode ? _prodRewarded : _testRewardedId;
  }
}
