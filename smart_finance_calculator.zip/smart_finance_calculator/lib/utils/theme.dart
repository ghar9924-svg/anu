import 'package:flutter/material.dart';

class AppTheme {
  // Premium Color Palette
  static const Color primaryBlue = Color(0xFF0052D4);
  static const Color primaryPurple = Color(0xFF654EA3);
  static const Color primaryGradientStart = Color(0xFF4364F7);
  static const Color primaryGradientEnd = Color(0xFF6FB1FC);
  
  static const Color backgroundLight = Color(0xFFF4F7FC);
  static const Color cardColorLight = Colors.white;
  
  static const Color textDark = Color(0xFF1E293B);
  static const Color textLight = Color(0xFF64748B);

  static const Color accentColor = Color(0xFF38BDF8);

  static const LinearGradient premiumGradient = LinearGradient(
    colors: [primaryGradientStart, primaryGradientEnd],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static ThemeData get lightTheme {
    return ThemeData(
      primaryColor: primaryBlue,
      scaffoldBackgroundColor: backgroundLight,
      colorScheme: ColorScheme.light(
        primary: primaryBlue,
        secondary: accentColor,
        background: backgroundLight,
        surface: cardColorLight,
      ),
      fontFamily: '.SF Pro Display', // Universal iOS default fallback mapping in Flutter
      textTheme: const TextTheme(
        displayLarge: TextStyle(color: textDark, fontWeight: FontWeight.bold, fontSize: 32),
        displayMedium: TextStyle(color: textDark, fontWeight: FontWeight.bold, fontSize: 28),
        headlineMedium: TextStyle(color: textDark, fontWeight: FontWeight.w700, fontSize: 24),
        titleLarge: TextStyle(color: textDark, fontWeight: FontWeight.w600, fontSize: 20),
        bodyLarge: TextStyle(color: textDark, fontSize: 16),
        bodyMedium: TextStyle(color: textLight, fontSize: 14),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: textDark),
        titleTextStyle: TextStyle(
          color: textDark,
          fontSize: 20,
          fontWeight: FontWeight.w600,
          fontFamily: '.SF Pro Display',
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryBlue,
          foregroundColor: Colors.white,
          elevation: 4,
          shadowColor: primaryBlue.withOpacity(0.4),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.symmetric(vertical: 16),
          textStyle: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: cardColorLight,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: primaryBlue, width: 2),
        ),
        labelStyle: const TextStyle(color: textLight),
      ),
    );
  }
}
