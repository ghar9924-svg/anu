# Smart Finance Calculator

A premium-quality iOS application built with Flutter, providing 10 high-value financial calculators and integrated with Google AdMob for monetization.

This codebase contains the complete robust implementation using Riverpod for state management and clean architecture. No Android code is present as requested.

---

## 2. Step-by-Step iOS Setup Guide (Mac + Xcode)

To run this Flutter project on a Mac for iOS, follow these steps:

### Prerequisites:
1. **Mac Computer** running macOS.
2. **Xcode** installed from the Mac App Store.
3. **Flutter SDK** installed. (Download from flutter.dev).
4. **CocoaPods** installed (`sudo gem install cocoapods`).

### Setup Steps:
1. Open terminal and navigate to the root directory of this project:
   ```bash
   cd path/to/smart_finance_calculator
   ```
2. Run `flutter pub get` to install all dependencies.
3. Since we didn't generate the `ios` folder using CLI (due to environment constraints), you need to initialize the iOS build files locally:
   ```bash
   flutter create --platforms ios .
   ```
   *This command safely injects missing platform folders without overwriting your Dart code.*
4. Navigate to the `ios` folder and install pods:
   ```bash
   cd ios
   pod install
   cd ..
   ```
5. Open the project in Xcode:
   ```bash
   open ios/Runner.xcworkspace
   ```

### Info.plist Configuration (AdMob Requirement):
In Xcode, open `Runner/Info.plist` and add the AdMob App ID and network configurations:

```xml
<key>GADApplicationIdentifier</key>
<string>YOUR_ADMOB_APP_ID_HERE</string>
<key>SKAdNetworkItems</key>
<array>
  <dict>
    <key>SKAdNetworkIdentifier</key>
    <string>cstr6suwn9.skadnetwork</string>
  </dict>
  <!-- Add other required SKAdNetworks from Google's guidelines -->
</array>
<key>NSUserTrackingUsageDescription</key>
<string>This identifier will be used to deliver personalized ads to you.</string>
```

---

## 3. How to Run App on Real iPhone

1. Connect your iPhone to your Mac via USB cable.
2. Open `ios/Runner.xcworkspace` in Xcode.
3. Go to **Xcode Settings > Accounts** and sign in with your Apple ID.
4. Click on the `Runner` target on the left panel, and go to the **Signing & Capabilities** tab.
5. Check "Automatically manage signing" and select your Team (your Apple ID).
6. Change the Bundle Identifier (e.g., `com.yourname.smartfinance`).
7. On your iPhone, go to **Settings > General > VPN & Device Management**, tap your Developer App certificate, and select "Trust".
8. Enable **Developer Mode** on your iPhone (Settings > Privacy & Security > Developer Mode).
9. From the terminal, run the app:
   ```bash
   flutter run -d <your-iphone-name>
   ```

---

## 4. How to Build IPA File

An `.ipa` file is the iOS app package file. To build it for distribution (e.g., TestFlight or App Store):

1. Ensure your app has App Icons configured (use a tool like `flutter_launcher_icons`).
2. Run the build command:
   ```bash
   flutter build ipa
   ```
3. This command creates a `.xcarchive` and subsequently an `.ipa` file inside `build/ios/ipa/`.

---

## 5. How to Upload to App Store

1. Go to [App Store Connect](https://appstoreconnect.apple.com/) and create a new App record using your Bundle Identifier.
2. Once the `flutter build ipa` command completes successfully, you can upload the IPA directly through the terminal:
   ```bash
   xcrun altool --upload-app --type ios -f build/ios/ipa/*.ipa --apiKey YOUR_API_KEY --apiIssuer YOUR_ISSUER_ID
   ```
   *Alternatively, you can open the generated `Runner.xcarchive` in Xcode Organizer and click "Distribute App", following the GUI prompts.*
3. Once uploaded, go to App Store Connect, select your app, set up your screenshots, description, keywords, and submit for review.

---

## 6. How to Replace Test Ads with Real AdMob Ads

Currently, the app uses Google's test ad units to prevent your account from being flagged for invalid traffic during development.

To switch to production ads:
1. Open `lib/services/ad_service.dart`.
2. Locate the static getter methods: `bannerAdUnitId`, `interstitialAdUnitId`, and `rewardedAdUnitId`.
3. Replace the placeholder strings `'YOUR_IOS_*_AD_UNIT_ID'` with the actual Ad Unit IDs from your AdMob Dashboard.
4. Open Xcode, modify `Runnner/Info.plist` and change `<key>GADApplicationIdentifier</key>` to your real AdMob App ID (starts with `ca-app-pub-...~...`).

*Note: Real ads will only show in `Release` mode (`flutter run --release` or `flutter build ipa`), because the code has a check `kReleaseMode`.*
